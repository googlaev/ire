from flask import Flask, request, jsonify
import os

import module2
def delete_files_in_directory(directory):
    # Перебираем все файлы в указанной директории
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        try:
            # Если это файл - удаляем его
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f'Ошибка при удалении файла {file_path}: {e}')




app = Flask(__name__)
# Загрузка изображения в папку upload_folder
@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    filename = file.filename
    save_path = os.path.join('upload_folder', filename)
    file.save(save_path)
    # Распознавание и отображение результата
    list_number = module2.img_to_string(save_path) #module2.carplate_recognition(directory='./upload_folder/*')
   
    # Возвращение результата в формате JSON
    result = {
        'image_number': list_number
    }
    delete_files_in_directory("./upload_folder/")  
    return jsonify(result)
# Запуск сервера
if __name__ == '__main__':
    app.run(debug=True)