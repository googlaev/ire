 
import module2


import os

# Функция для обработки директории
def process_directory(directory_path):
    for root, dirs, files in os.walk(directory_path):
        for file_name in files:
            file_path = os.path.join(root, file_name)
            # Распознавание и отображение результата
            module2.img_to_string( file_path)

# Укажите путь к директории, которую вы хотите обработать
directory_path = "./cars"

# Вызов функции для обработки директории изображений для распознавания
process_directory(directory_path)